import '../helper/enum.dart';

class UserSearchModel {
  int? isOnline;
  int? isExactMatch;
  SearchFrom? searchFrom;
  String? searchText;

  UserSearchModel();
}
