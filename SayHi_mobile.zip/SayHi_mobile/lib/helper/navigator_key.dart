import 'package:flutter/material.dart';

class NoomiKeys {
  static final navKey =  GlobalKey<NavigatorState>();
}